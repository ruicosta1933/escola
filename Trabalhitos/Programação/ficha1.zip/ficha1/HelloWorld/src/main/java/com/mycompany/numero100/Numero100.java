/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.numero100;

import java.util.Scanner;

/**
 *
 * @author ruicosta
 */
public class Numero100 {
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        int i;
        
        for(i=1; i<=100; i++){
           System.out.println(i);
        }
    }
 }